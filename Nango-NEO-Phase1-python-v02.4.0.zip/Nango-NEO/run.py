#!/usr/bin/env python3
"""Launch Nango-neo locally using only Python's standard library.

Usage: python run.py [--port 8765] [--no-browser]
"""
from __future__ import annotations
import argparse
import http.server
import socket
import threading
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "Nango-neo"
ENTRY = "/Nango-neo.v02.4.0.html"

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)
    def log_message(self, fmt, *args):
        # Keep the console quiet unless there is an error.
        if args and str(args[1]).startswith("4") or args and str(args[1]).startswith("5"):
            super().log_message(fmt, *args)

def find_port(preferred: int) -> int:
    for port in range(preferred, preferred + 20):
        with socket.socket() as sock:
            try:
                sock.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("空いているポートが見つかりませんでした。")

def main() -> None:
    parser = argparse.ArgumentParser(description="Nango-neo をローカルで起動します")
    parser.add_argument("--port", type=int, default=8765, help="ポート番号（既定: 8765）")
    parser.add_argument("--no-browser", action="store_true", help="ブラウザーを自動で開かない")
    args = parser.parse_args()
    if not (ROOT / ENTRY.lstrip("/")).is_file():
        raise SystemExit(f"アプリのHTMLが見つかりません: {ROOT / ENTRY.lstrip('/')}")
    port = find_port(args.port)
    server = http.server.ThreadingHTTPServer(("127.0.0.1", port), QuietHandler)
    url = f"http://127.0.0.1:{port}{ENTRY}"
    print(f"Nango-neo を起動しました: {url}")
    print("終了するには、このウィンドウで Ctrl+C を押してください。")
    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nNango-neo を終了します。")
    finally:
        server.server_close()

if __name__ == "__main__":
    main()
