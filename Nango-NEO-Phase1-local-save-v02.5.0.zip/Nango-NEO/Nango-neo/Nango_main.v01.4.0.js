/* Nango-neo Phase 1
 * Canonical file format: DTformats.neo.v5.14 (words object keyed by displayed word).
 * The UI uses an internal array; conversion happens only at load/import/export boundaries.
 */
'use strict';

const STORAGE_KEY = 'nango_data';
const FORMAT_VERSION = 'DTformats.neo.v5.14';
const nowIso = () => new Date().toISOString();

const defaultData = [
    {
        word: 'カスケード', id: 1, datetime: '2026-10-09T00:00:00+09:00',
        category: '外来語', eraTag: '現代', reading: 'かすけーど', kanji: '', english: 'cascade',
        column: '上流から下流へとつながっていく様子を表す語。', memo: '', gemini_note: '', other_tags: ['IT'],
        meanings: [{
            definition: '連鎖的に物事が起きること。または、階段状に流れ落ちる滝や、そのように連なるもの。',
            background: '英語 cascade は、滝を意味する語に由来する。IT、ビジネス、科学などで、一つの事象が次々と別の事象を引き起こす現象を表す。',
            nuance: '単に連続するだけでなく、上流から下流へ、ある事象をきっかけに次々と波及する印象がある。',
            fieldTag: ['エンジニアリング'],
            examples: [
                '小さな設定ミスがカスケード障害を引き起こした。',
                'CSSではスタイルが優先順位に従ってカスケードする。'
            ], synonyms: ['連鎖', '波及', 'ドミノ倒し']
        }]
    },
    {
        word: '傅く', id: 2, datetime: '2026-10-09T00:00:00+09:00',
        category: '古語・大和言葉', eraTag: '中世', reading: 'かしづく', kanji: '傅く', english: '',
        column: '', memo: '', gemini_note: '', other_tags: [],
        meanings: [{
            definition: '人に仕えて大切に世話をする。また、子供を大切に養い育てる。',
            background: '古語「かしづく」に由来し、貴人に仕えることや、子どもを慈しみ育てることを指した。',
            nuance: '深い敬意や愛情をこめて世話をするニュアンスがあり、現代では文学的な表現として見られる。',
            fieldTag: ['日常', '日本語史'],
            examples: ['若き女王に傅く侍従たちが控えていた。'], synonyms: ['仕える', 'お世話する', '奉公する']
        }]
    }
];

let wordData = [];
let additionalData = [];
let currentWordId = -1;
let isNewWord = false;
let searchQuery = '';
let currentSort = 'id';
let currentHierarchy = 'category';
let openCategories = {};
let pastePanelOpen = false;
let meaningClipboard = null;
let wordListTagFilter = null;
let appNavigationHistory = [];
let appNavigationIndex = -1;
let restoringNavigation = false;
const tagTableSortState = {};
let wordListColumnSort = { key: null, direction: 'asc' };

function currentScreenSnapshot(screen, extra = {}) {
    return {
        screen,
        wordId: currentWordId,
        tagFilter: wordListTagFilter ? { ...wordListTagFilter } : null,
        wordListSearch: $('wordListSearch')?.value || '',
        wordListSort: $('wordListSort')?.value || 'id',
        wordListDirection: $('wordListDirection')?.value || 'asc',
        pasteText: $('jsonPasteInput')?.value || '',
        ...extra
    };
}
function recordAppNavigation(screen, extra = {}) {
    if (restoringNavigation) return;
    const snapshot = currentScreenSnapshot(screen, extra);
    const previous = appNavigationHistory[appNavigationIndex];
    if (previous && JSON.stringify(previous) === JSON.stringify(snapshot)) return;
    appNavigationHistory = appNavigationHistory.slice(0, appNavigationIndex + 1);
    appNavigationHistory.push(snapshot);
    if (appNavigationHistory.length > 100) appNavigationHistory.shift();
    appNavigationIndex = appNavigationHistory.length - 1;
    updateAppNavigationButtons();
}
function updateAppNavigationButtons() {
    const back = $('pageBackBtn'), forward = $('pageForwardBtn');
    if (back) back.disabled = appNavigationIndex <= 0;
    if (forward) forward.disabled = appNavigationIndex < 0 || appNavigationIndex >= appNavigationHistory.length - 1;
}
function navigateAppHistory(delta) {
    const next = appNavigationIndex + delta;
    if (next < 0 || next >= appNavigationHistory.length) return;
    appNavigationIndex = next;
    restoreAppNavigation(appNavigationHistory[appNavigationIndex]);
    updateAppNavigationButtons();
}
function restoreAppNavigation(state) {
    restoringNavigation = true;
    currentWordId = state.wordId;
    wordListTagFilter = state.tagFilter ? { ...state.tagFilter } : null;
    $('viewMode').style.display = 'none';
    $('editMode').style.display = 'none';
    $('managePanelMode').style.display = 'none';
    $('pastePanelMode').style.display = 'none';
    $('wordListMode').style.display = 'none';
    if (state.screen === 'edit') {
        const word = wordData.find(item => item.id === currentWordId);
        if (word) { isNewWord = false; $('formTitle').textContent = '単語の編集'; populateEditor(word); }
        $('editMode').style.display = 'block';
    } else if (state.screen === 'new') {
        isNewWord = true; $('formTitle').textContent = '新規単語追加';
        populateEditor({ word: '', category: '指定なし', eraTag: '', reading: '', kanji: '', english: '', column: '', memo: '', gemini_note: '', other_tags: [], meanings: [{}] });
        $('editMode').style.display = 'block';
    } else if (state.screen === 'manage') {
        $('managePanelMode').style.display = 'block'; renderTagManagementTables();
    } else if (state.screen === 'paste') {
        $('pastePanelMode').style.display = 'block'; $('jsonPasteInput').value = state.pasteText || '';
    } else if (state.screen === 'wordList' || state.screen === 'tagWords') {
        $('wordListMode').style.display = 'block';
        $('wordListSearch').value = state.wordListSearch || '';
        $('wordListSort').value = state.wordListSort || 'id';
        $('wordListDirection').value = state.wordListDirection || 'asc';
        const filterBox = $('wordListTagFilter');
        if (wordListTagFilter) {
            filterBox.style.display = 'flex';
            filterBox.innerHTML = `タグ「<strong>${escapeHtml(wordListTagFilter.tag)}</strong>」が付いた単語 <button type="button" class="btn-sm" id="clearWordListTagFilter">タグ絞り込み解除</button>`;
            $('clearWordListTagFilter').onclick = () => { wordListTagFilter = null; filterBox.style.display = 'none'; renderWordList(); recordAppNavigation('wordList'); };
        } else { filterBox.style.display = 'none'; filterBox.textContent = ''; }
        renderWordList();
    } else {
        $('viewMode').style.display = 'block'; showViewMode(false);
    }
    renderSidebarTree();
    restoringNavigation = false;
    updateAppNavigationButtons();
}


const $ = (id) => document.getElementById(id);
const clone = (value) => JSON.parse(JSON.stringify(value));
const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
const asString = (value) => typeof value === 'string' ? value : (value == null ? '' : String(value));
const asStringArray = (value) => Array.isArray(value) ? value.map(asString).map(s => s.trim()).filter(Boolean) : (typeof value === 'string' && value.trim() ? [value.trim()] : []);
const normalizeText = (value) => asString(value).normalize('NFKC').toLocaleLowerCase('ja').replace(/[\s　]+/g, ' ').trim();
const unique = (values) => [...new Set(values.map(v => asString(v).trim()).filter(Boolean))];

function normalizeLegacyKeys(value) {
    if (Array.isArray(value)) return value.map(normalizeLegacyKeys);
    if (!value || typeof value !== 'object') return value;
    const out = {};
    for (const [key, item] of Object.entries(value)) {
        if (key.startsWith('//')) continue;
        const cleanKey = key.endsWith('$') ? key.slice(0, -1) : key;
        if (Object.prototype.hasOwnProperty.call(out, cleanKey) && JSON.stringify(out[cleanKey]) !== JSON.stringify(item)) {
            throw new Error(`必須項目マーカー除去後にキーが重複しました: ${cleanKey}`);
        }
        out[cleanKey] = normalizeLegacyKeys(item);
    }
    return out;
}

function isRfc3339DateTime(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value)) return false;
    return Number.isFinite(Date.parse(value));
}

function normalizeFieldTags(value) {
    // Older AI-generated records sometimes packed several domain tags into one
    // string with a middle dot (e.g. 'IT・美容・ライフスタイル'). Normalize
    // those into independent tags while keeping other tag fields untouched.
    const source = Array.isArray(value) ? value : (typeof value === 'string' ? [value] : []);
    return unique(source.flatMap(item => asString(item).split(/[・,，、\n]/)));
}

function normalizeMeaning(raw = {}) {
    return {
        definition: asString(raw.definition),
        background: asString(raw.background),
        nuance: asString(raw.nuance),
        fieldTag: normalizeFieldTags(raw.fieldTag),
        examples: asStringArray(raw.examples),
        synonyms: asStringArray(raw.synonyms)
    };
}

function normalizeDisplayName(item, rawWord) {
    const word = asString(rawWord).trim();
    const match = /^(.*?)\s*[（(]([^（）()]*)[）)]$/.exec(word);
    if (!match || !match[1].trim()) return word;
    const base = match[1].trim();
    const inner = match[2].trim();
    const reading = asString(item.reading).trim();
    const category = asString(item.category);
    const foreignOrSpecial = Boolean(asString(item.english).trim()) ||
        /外来語|外国語|略語|記号|原語|英語/.test(category);

    // Display names no longer append readings in parentheses. Keep reading in
    // the dedicated reading field, and preserve legacy foreign spellings in english.
    if (reading && normalizeText(inner) === normalizeText(reading)) return base;
    const kanji = asString(item.kanji).trim();
    if (kanji && inner === kanji && /^[ぁ-ゖァ-ヺー]+$/.test(base)) return kanji;
    if (foreignOrSpecial) {
        if (!asString(item.english).trim() && inner) item.english = inner;
        return base;
    }
    return word;
}

function normalizeWord(raw = {}, key = '') {
    const item = { ...raw };
    const word = normalizeDisplayName(item, asString(item.word || key).trim());
    if (!word) throw new Error('単語名（wordsオブジェクトのキー）が空です。');

    let meanings;
    if (Array.isArray(item.meanings)) {
        meanings = item.meanings.map(normalizeMeaning);
    } else if (item.meaning !== undefined || item.background !== undefined || item.nuance !== undefined || item.examples !== undefined || item.synonyms !== undefined) {
        meanings = [normalizeMeaning({
            definition: item.meaning, background: item.background, nuance: item.nuance,
            fieldTag: item.fieldTag, examples: item.examples, synonyms: item.synonyms
        })];
    } else {
        meanings = [];
    }
    if (!meanings.length) throw new Error(`「${word}」に meanings がありません。最低1つの意味を登録してください。`);

    const base = { ...item };
    ['word', 'word(any)', 'word_any', 'meaning', 'background', 'nuance', 'fieldTag', 'examples', 'synonyms'].forEach(keyName => delete base[keyName]);
    return {
        ...base,
        id: Number.isInteger(item.id) && item.id > 0 ? item.id : 0,
        datetime: isRfc3339DateTime(item.datetime) ? asString(item.datetime) : nowIso(),
        word,
        category: asString(item.category).trim() || '指定なし',
        eraTag: asString(item.eraTag),
        reading: asString(item.reading),
        kanji: asString(item.kanji),
        english: asString(item.english),
        column: asString(item.column),
        memo: asString(item.memo),
        gemini_note: asString(item.gemini_note),
        other_tags: asStringArray(item.other_tags),
        meanings
    };
}

function parseNangoDocument(documentValue) {
    const source = normalizeLegacyKeys(documentValue);
    let entries = [];
    let extra = [];
    if (Array.isArray(source)) {
        // Compatibility with old app exports (array of records).
        entries = source.map((item, i) => normalizeWord(item, item.word || `legacy-${i + 1}`));
    } else if (source && typeof source === 'object' && source.words && !Array.isArray(source.words) && typeof source.words === 'object') {
        entries = Object.entries(source.words).map(([key, value]) => {
            validateCanonicalWord(key, value);
            return normalizeWord(value, key);
        });
        if (source.additional_data !== undefined && (!Array.isArray(source.additional_data) || !source.additional_data.every(value => typeof value === 'string'))) {
            throw new Error('additional_data は文字列の配列である必要があります。');
        }
        extra = asStringArray(source.additional_data);
    } else if (source && typeof source === 'object' && Array.isArray(source.words)) {
        // A short-lived historical shape used a list under words.
        entries = source.words.map((item, i) => normalizeWord(item, item.word || `legacy-${i + 1}`));
        extra = asStringArray(source.additional_data);
    } else {
        throw new Error('Nango形式ではありません。トップレベルに words オブジェクトが必要です。');
    }

    const seen = new Set();
    for (const item of entries) {
        const key = normalizeText(item.word);
        if (seen.has(key)) throw new Error(`同じファイル内に同一の単語名があります: 「${item.word}」`);
        seen.add(key);
        validateWord(item);
    }
    return { words: entries, additional_data: extra };
}

function validateCanonicalWord(wordName, raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error(`「${wordName}」のデータはオブジェクトである必要があります。`);
    const stringFields = ['datetime', 'category', 'eraTag', 'reading', 'kanji', 'english', 'column', 'memo', 'gemini_note'];
    for (const field of stringFields) {
        if (raw[field] !== undefined && typeof raw[field] !== 'string') throw new Error(`「${wordName}」の ${field} は文字列である必要があります。`);
    }
    if (raw.id !== undefined && (!Number.isInteger(raw.id) || raw.id < 1)) throw new Error(`「${wordName}」の id は1以上の整数である必要があります。`);
    if (raw.datetime !== undefined && !isRfc3339DateTime(raw.datetime)) throw new Error(`「${wordName}」の datetime は RFC 3339形式である必要があります。`);
    if (raw.other_tags !== undefined && (!Array.isArray(raw.other_tags) || !raw.other_tags.every(value => typeof value === 'string'))) {
        throw new Error(`「${wordName}」の other_tags は文字列配列である必要があります。`);
    }
    if (!Array.isArray(raw.meanings) || raw.meanings.length === 0) throw new Error(`「${wordName}」には meanings が1つ以上必要です。`);
    raw.meanings.forEach((meaning, index) => {
        if (!meaning || typeof meaning !== 'object' || Array.isArray(meaning)) throw new Error(`「${wordName}」の meanings[${index}] はオブジェクトである必要があります。`);
        if (typeof meaning.definition !== 'string' || !meaning.definition.trim()) throw new Error(`「${wordName}」の意味 ${index + 1}: definition は必須の文字列です。`);
        for (const field of ['background', 'nuance']) {
            if (meaning[field] !== undefined && typeof meaning[field] !== 'string') throw new Error(`「${wordName}」の意味 ${index + 1}: ${field} は文字列である必要があります。`);
        }
        for (const field of ['fieldTag', 'examples', 'synonyms']) {
            if (meaning[field] !== undefined && (!Array.isArray(meaning[field]) || !meaning[field].every(value => typeof value === 'string'))) {
                throw new Error(`「${wordName}」の意味 ${index + 1}: ${field} は文字列配列である必要があります。`);
            }
        }
    });
}

function validateWord(word) {
    if (!word.word.trim()) throw new Error('単語名は必須です。');
    if (!Array.isArray(word.meanings) || word.meanings.length === 0) throw new Error(`「${word.word}」には意味が1つ以上必要です。`);
    for (let i = 0; i < word.meanings.length; i++) {
        const meaning = word.meanings[i];
        if (!meaning.definition.trim()) throw new Error(`「${word.word}」の意味 ${i + 1}: definition は必須です。`);
        for (const key of ['fieldTag', 'examples', 'synonyms']) {
            if (!Array.isArray(meaning[key]) || !meaning[key].every(value => typeof value === 'string')) {
                throw new Error(`「${word.word}」の意味 ${i + 1}: ${key} は文字列配列である必要があります。`);
            }
        }
    }
}

function serializeNangoDocument(items = wordData, extra = additionalData) {
    const words = {};
    const seenNames = new Set();
    const sorted = [...items].sort((a, b) => a.id - b.id);
    for (const source of sorted) {
        const item = normalizeWord(source, source.word);
        validateWord(item);
        const uniqueName = normalizeText(item.word);
        if (seenNames.has(uniqueName)) throw new Error(`辞書形式では同じ単語名を重複登録できません: 「${item.word}」`);
        seenNames.add(uniqueName);
        const payload = { ...item };
        delete payload.word;
        words[item.word] = payload;
    }
    return { words, additional_data: asStringArray(extra) };
}

function reassignIds(items, start = 1) {
    return items.map((item, index) => ({ ...item, id: start + index }));
}

function initApp() {
    try {
        const savedData = localStorage.getItem(STORAGE_KEY);
        if (savedData) {
            const parsed = parseNangoDocument(JSON.parse(savedData));
            wordData = reassignIds(parsed.words.slice().sort((a, b) => (a.id || 0) - (b.id || 0)));
            additionalData = parsed.additional_data;
            // Persist the canonical v5.13 shape immediately, so old localStorage arrays migrate once on startup.
            try { saveToLocalStorage(); } catch (saveError) { console.warn('保存データの形式変換を保存できませんでした:', saveError); }
        } else {
            wordData = reassignIds(clone(defaultData));
            additionalData = [];
            saveToLocalStorage();
        }
    } catch (error) {
        console.error('Nangoデータの読み込みに失敗しました:', error);
        wordData = reassignIds(clone(defaultData));
        additionalData = [];
        try { saveToLocalStorage(); } catch (saveError) { console.error('初期データを保存できません:', saveError); }
        alert(`保存データを読み込めなかったため、初期データで起動しました。\n${error.message}\n必要であれば、ブラウザーの保存データを削除する前にバックアップしてください。`);
    }
    refreshOpenState();
    currentWordId = wordData.length ? wordData[0].id : -1;
    renderSidebarTree();
    showViewMode();
}

function saveToLocalStorage() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(serializeNangoDocument()));
}

function refreshOpenState() {
    openCategories = {};
    wordData.forEach(word => getGroupingValues(word).forEach(key => { openCategories[key] = true; }));
}

function getGroupingValues(word) {
    if (currentHierarchy === 'fieldTag') return unique(word.meanings.flatMap(m => m.fieldTag || [])).length ? unique(word.meanings.flatMap(m => m.fieldTag || [])) : ['(未設定)'];
    const value = word[currentHierarchy];
    return value ? [value] : ['(未設定)'];
}

function setSort(type) {
    currentSort = type;
    $('sort-id').classList.toggle('active', type === 'id');
    $('sort-alpha').classList.toggle('active', type === 'alpha');
    renderSidebarTree();
}

function setHierarchyStructure(type) {
    currentHierarchy = type;
    $('struct-cat').classList.toggle('active', type === 'category');
    $('struct-field').classList.toggle('active', type === 'fieldTag');
    $('struct-era').classList.toggle('active', type === 'eraTag');
    refreshOpenState();
    renderSidebarTree();
}

function handleSearch() {
    searchQuery = $('searchInput').value.trim().toLocaleLowerCase('ja');
    renderSidebarTree();
}

function searchableText(word) {
    return [word.word, word.reading, word.kanji, word.english, word.category, word.eraTag, word.column,
        word.memo, word.gemini_note, ...(word.other_tags || []), ...word.meanings.flatMap(m => [
            m.definition, m.background, m.nuance, ...m.fieldTag, ...m.examples, ...m.synonyms
        ])].join(' ').toLocaleLowerCase('ja');
}

function getProcessedWords() {
    let result = wordData.filter(word => !searchQuery || searchableText(word).includes(searchQuery));
    result = [...result];
    if (currentSort === 'alpha') result.sort((a, b) => (a.reading || a.word).localeCompare(b.reading || b.word, 'ja'));
    else result.sort((a, b) => a.id - b.id);
    return result;
}

function renderSidebarTree() {
    const container = $('treeContainer');
    container.replaceChildren();
    const processed = getProcessedWords();
    if (!processed.length) {
        container.innerHTML = '<div class="empty-message">該当する単語はありません</div>';
        $('exportBtn').disabled = true;
        return;
    }
    const groups = new Map();
    for (const word of processed) {
        for (const key of getGroupingValues(word)) {
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(word);
        }
    }
    for (const groupName of [...groups.keys()].sort((a, b) => a.localeCompare(b, 'ja'))) {
        const categoryDiv = document.createElement('div');
        categoryDiv.className = `tree-category ${openCategories[groupName] ? 'open' : ''}`;
        const header = document.createElement('div');
        header.className = 'tree-category-header';
        header.innerHTML = `<span class="tree-category-title"><span class="tree-toggle-icon">▶</span> ${escapeHtml(groupName)} (${groups.get(groupName).length})</span>`;
        header.onclick = () => {
            categoryDiv.classList.toggle('open');
            openCategories[groupName] = categoryDiv.classList.contains('open');
        };
        const list = document.createElement('div');
        list.className = 'tree-word-list';
        groups.get(groupName).forEach(word => {
            const button = document.createElement('button');
            button.className = `tree-word-item ${word.id === currentWordId ? 'active' : ''}`;
            button.textContent = word.word;
            button.title = word.word;
            button.onclick = () => { currentWordId = word.id; renderSidebarTree(); showViewMode(); };
            list.appendChild(button);
        });
        categoryDiv.append(header, list);
        container.appendChild(categoryDiv);
    }
    $('exportBtn').disabled = wordData.length === 0;
}

function showViewMode(recordHistory = true) {
    if (recordHistory) recordAppNavigation('view');
    $('editMode').style.display = 'none';
    $('managePanelMode').style.display = 'none';
    $('pastePanelMode').style.display = 'none';
    $('wordListMode').style.display = 'none';
    $('viewMode').style.display = 'block';
    const target = $('viewTarget');
    const current = wordData.find(item => item.id === currentWordId);
    $('editBtn').style.display = current ? 'inline-block' : 'none';
    $('deleteBtn').style.display = current ? 'inline-block' : 'none';
    if (!current) {
        target.innerHTML = '<div class="empty-message">表示する単語がありません。JSONをインポートするか、新規単語を追加してください。</div>';
        return;
    }
    const fieldTags = unique(current.meanings.flatMap(m => m.fieldTag || []));
    const metadata = [
        current.reading ? `よみがな: ${current.reading}` : '', current.kanji ? `漢字: ${current.kanji}` : '',
        current.english ? `スペル: ${current.english}` : '', `ID: ${current.id}`
    ].filter(Boolean).join(' | ');
    const badges = [
        ...fieldTags.map(tag => `<button type="button" class="custom-tag tag-field tag-link" data-tag-type="fieldTag" data-tag-value="${escapeHtml(tag)}">分野: ${escapeHtml(tag)}</button>`),
        current.eraTag ? `<button type="button" class="custom-tag tag-era tag-link" data-tag-type="eraTag" data-tag-value="${escapeHtml(current.eraTag)}">時代: ${escapeHtml(current.eraTag)}</button>` : '',
        ...(current.other_tags || []).map(tag => `<button type="button" class="custom-tag tag-other tag-link" data-tag-type="other_tags" data-tag-value="${escapeHtml(tag)}">${escapeHtml(tag)}</button>`)
    ].filter(Boolean).join('');
    const meaningsHtml = current.meanings.map((meaning, index) => `
        <section class="meaning-card">
            <h3>意味 ${index + 1}</h3>
            <div class="section-title">意味・定義</div><div class="meaning-box">${escapeHtml(meaning.definition)}</div>
            ${meaning.background ? `<div class="section-title">背景 / 由来</div><div class="text-content">${escapeHtml(meaning.background)}</div>` : ''}
            ${meaning.nuance ? `<div class="section-title">ニュアンス</div><div class="text-content">${escapeHtml(meaning.nuance)}</div>` : ''}
            ${meaning.examples.length ? `<div class="section-title">例文</div><ul class="example-list">${meaning.examples.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul>` : ''}
            ${meaning.synonyms.length ? `<div class="section-title">類義語</div><div class="synonym-container">${meaning.synonyms.map(item => `<span class="synonym-tag">${escapeHtml(item)}</span>`).join('')}</div>` : ''}
            ${meaning.fieldTag.length ? `<div class="section-title">分野タグ</div><div class="tag-container">${meaning.fieldTag.map(tag => `<button type="button" class="custom-tag tag-field tag-link" data-tag-type="fieldTag" data-tag-value="${escapeHtml(tag)}">${escapeHtml(tag)}</button>`).join('')}</div>` : ''}
        </section>`).join('');
    target.innerHTML = `
        <div class="word-header-container"><div class="word-title-row"><h2 class="word-title">${escapeHtml(current.word)}</h2><span class="category-badge">${escapeHtml(current.category || '指定なし')}</span></div>
        ${badges ? `<div class="tag-container">${badges}</div>` : ''}${metadata ? `<div class="word-sub-info">${escapeHtml(metadata)}</div>` : ''}</div>
        ${meaningsHtml}
        ${current.column ? `<div class="section-title">コラム</div><div class="text-content">${escapeHtml(current.column)}</div>` : ''}
        ${current.memo ? `<div class="section-title">メモ</div><div class="text-content">${escapeHtml(current.memo)}</div>` : ''}
        ${current.gemini_note ? `<div class="section-title">AIからの一言</div><div class="text-content">${escapeHtml(current.gemini_note)}</div>` : ''}
        <div class="word-sub-info">登録日時: ${escapeHtml(current.datetime)}</div>`;
    target.querySelectorAll('[data-tag-type][data-tag-value]').forEach(tagButton => {
        tagButton.addEventListener('click', () => showWordsForTag(tagButton.dataset.tagType, tagButton.dataset.tagValue));
    });
}

function renderMeaningEditor(meaning = {}, index = 0) {
    const normalized = normalizeMeaning(meaning);
    const section = document.createElement('section');
    section.className = 'meaning-editor-card';
    section.dataset.meaningIndex = String(index);
    section.innerHTML = `
        <div class="meaning-editor-header"><h3>意味 ${index + 1}</h3><div class="meaning-actions">
          <button type="button" class="btn-sm" data-action="copy">コピー</button>
          <button type="button" class="btn-sm" data-action="duplicate">複製</button>
          <button type="button" class="btn-sm" data-action="up">↑</button>
          <button type="button" class="btn-sm" data-action="down">↓</button>
          <button type="button" class="btn-sm btn-danger-sm" data-action="delete">削除</button>
        </div></div>
        <div class="form-group"><label>意味・定義 *必須</label><textarea class="form-control meaning-definition" required>${escapeHtml(normalized.definition)}</textarea></div>
        <div class="form-group"><label>背景 / 由来</label><textarea class="form-control meaning-background">${escapeHtml(normalized.background)}</textarea></div>
        <div class="form-group"><label>ニュアンス</label><textarea class="form-control meaning-nuance">${escapeHtml(normalized.nuance)}</textarea></div>
        <div class="form-group"><label>分野タグ（タグごとに入力。カンマ・中点「・」・改行で区切り）</label><input class="form-control meaning-fieldTag" value="${escapeHtml(normalized.fieldTag.join(', '))}"></div>
        <div class="form-group"><label>例文（1行に1文）</label><textarea class="form-control meaning-examples">${escapeHtml(normalized.examples.join('\n'))}</textarea></div>
        <div class="form-group"><label>類義語（カンマ、読点、改行区切り）</label><textarea class="form-control meaning-synonyms">${escapeHtml(normalized.synonyms.join('\n'))}</textarea></div>`;
    section.querySelectorAll('[data-action]').forEach(button => {
        button.onclick = () => handleMeaningAction(section, button.dataset.action);
    });
    return section;
}

function splitList(value) { return unique(asString(value).split(/[,，、\n]/)); }
function splitTagList(value) { return normalizeFieldTags(value); }
function readMeaningEditors() {
    return [...$('meaningsEditor').querySelectorAll('.meaning-editor-card')].map(card => ({
        definition: card.querySelector('.meaning-definition').value.trim(),
        background: card.querySelector('.meaning-background').value.trim(),
        nuance: card.querySelector('.meaning-nuance').value.trim(),
        fieldTag: splitTagList(card.querySelector('.meaning-fieldTag').value),
        examples: asStringArray(card.querySelector('.meaning-examples').value.split('\n')),
        synonyms: splitList(card.querySelector('.meaning-synonyms').value)
    }));
}
function refreshMeaningEditorTitles() {
    [...$('meaningsEditor').querySelectorAll('.meaning-editor-card')].forEach((card, index) => {
        card.dataset.meaningIndex = String(index);
        card.querySelector('h3').textContent = `意味 ${index + 1}`;
    });
}
function addMeaningEditor(data = {}) {
    $('meaningsEditor').appendChild(renderMeaningEditor(data, $('meaningsEditor').children.length));
    refreshMeaningEditorTitles();
}
function pasteMeaningEditor() {
    if (!meaningClipboard) { alert('コピーした意味がありません。各意味の「コピー」を押してください。'); return; }
    addMeaningEditor(clone(meaningClipboard));
}
function handleMeaningAction(card, action) {
    const cards = [...$('meaningsEditor').querySelectorAll('.meaning-editor-card')];
    const index = cards.indexOf(card);
    if (action === 'copy') {
        meaningClipboard = clone(readMeaningEditors()[index]);
        $('pasteMeaningBtn').disabled = false;
        alert('意味をコピーしました。「意味を貼り付け」から追加できます。');
    }
    if (action === 'duplicate') $('meaningsEditor').insertBefore(renderMeaningEditor(readMeaningEditors()[index], index + 1), card.nextSibling);
    if (action === 'delete') {
        if (cards.length === 1) { alert('意味は最低1つ必要です。'); return; }
        card.remove();
    }
    if (action === 'up' && index > 0) $('meaningsEditor').insertBefore(card, cards[index - 1]);
    if (action === 'down' && index < cards.length - 1) $('meaningsEditor').insertBefore(cards[index + 1], card);
    refreshMeaningEditorTitles();
}

function populateEditor(word) {
    $('editWord').value = word.word || '';
    $('editCategory').value = word.category || '指定なし';
    $('editEraTag').value = word.eraTag || '';
    $('editReading').value = word.reading || '';
    $('editKanji').value = word.kanji || '';
    $('editEnglish').value = word.english || '';
    $('editColumn').value = word.column || '';
    $('editMemo').value = word.memo || '';
    $('editGeminiNote').value = word.gemini_note || '';
    $('editOtherTags').value = (word.other_tags || []).join(', ');
    $('meaningsEditor').replaceChildren();
    (word.meanings && word.meanings.length ? word.meanings : [{}]).forEach(addMeaningEditor);
}
function showEditForm() {
    recordAppNavigation('edit');
    const word = wordData.find(item => item.id === currentWordId);
    if (!word) return;
    isNewWord = false;
    $('formTitle').textContent = '単語の編集';
    $('viewMode').style.display = 'none'; $('managePanelMode').style.display = 'none'; $('pastePanelMode').style.display = 'none'; $('wordListMode').style.display = 'none'; $('editMode').style.display = 'block';
    populateEditor(word);
}
function showNewForm() {
    recordAppNavigation('new');
    isNewWord = true;
    $('formTitle').textContent = '新規単語追加';
    $('viewMode').style.display = 'none'; $('managePanelMode').style.display = 'none'; $('pastePanelMode').style.display = 'none'; $('wordListMode').style.display = 'none'; $('editMode').style.display = 'block';
    populateEditor({ word: '', category: '指定なし', eraTag: '', reading: '', kanji: '', english: '', column: '', memo: '', gemini_note: '', other_tags: [], meanings: [{}] });
}
function cancelEdit() { showViewMode(); }

function collectEditorWord() {
    const wordName = $('editWord').value.trim();
    if (!wordName) throw new Error('単語（表記）は必須入力です。');
    const meanings = readMeaningEditors();
    if (!meanings.length || meanings.some(meaning => !meaning.definition)) throw new Error('各意味の「意味・定義」は必須入力です。');
    const collected = {
        word: wordName, id: 0, datetime: nowIso(), category: $('editCategory').value || '指定なし',
        eraTag: $('editEraTag').value.trim(), reading: $('editReading').value.trim(),
        kanji: $('editKanji').value.trim(), english: $('editEnglish').value.trim(),
        column: $('editColumn').value.trim(), memo: $('editMemo').value.trim(),
        gemini_note: $('editGeminiNote').value.trim(), other_tags: splitList($('editOtherTags').value), meanings
    };
    collected.word = normalizeDisplayName(collected, wordName);
    return collected;
}
function saveWord() {
    try {
        const collected = collectEditorWord();
        if (isNewWord) {
            const duplicateIndex = findDuplicateIndex(collected, wordData);
            if (duplicateIndex >= 0) {
                const existing = wordData[duplicateIndex];
                if (!confirm(`「${collected.word}」は「${existing.word}」と同じ単語として扱われます。既存の単語にマージしますか？\n\nOK: 既存データに追加・マージ\nキャンセル: 登録を中止`)) return;
                wordData[duplicateIndex] = mergeWord(existing, collected);
                currentWordId = existing.id;
            } else {
                collected.id = nextId(wordData);
                wordData.push(collected);
                currentWordId = collected.id;
            }
        } else {
            const index = wordData.findIndex(item => item.id === currentWordId);
            if (index < 0) throw new Error('編集対象の単語が見つかりません。');
            const duplicateIndex = findDuplicateIndex(collected, wordData.filter(item => item.id !== currentWordId));
            if (duplicateIndex >= 0) throw new Error('同じ単語名または原語表記の単語が既にあります。単語名を変更するか、JSONインポートのマージ機能を使用してください。');
            collected.id = wordData[index].id;
            collected.datetime = wordData[index].datetime;
            wordData[index] = collected;
        }
        saveToLocalStorage(); refreshOpenState(); renderSidebarTree(); showViewMode();
    } catch (error) { alert(error.message); }
}
function nextId(items) { return items.reduce((max, item) => Math.max(max, Number(item.id) || 0), 0) + 1; }

function deleteCurrentWord() {
    const current = wordData.find(item => item.id === currentWordId);
    if (!current || !confirm(`「${current.word}」を削除してもよろしいですか？`)) return;
    wordData = wordData.filter(item => item.id !== currentWordId);
    currentWordId = wordData.length ? wordData[0].id : -1;
    saveToLocalStorage(); refreshOpenState(); renderSidebarTree(); showViewMode();
}

function baseWordIdentity(value) {
    return normalizeText(value)
        .replace(/[（(][^（）()]*[）)]/g, '')
        .replace(/[「」『』【】\[\]{}]/g, '')
        .trim();
}
function wordIdentities(word) {
    const identities = new Set([baseWordIdentity(word.word), normalizeText(word.word)]);
    // Parenthesized Latin spelling is considered an alias of the displayed name.
    const spellings = asString(word.word).match(/[（(]([^（）()]*)[）)]/g) || [];
    spellings.forEach(text => identities.add(normalizeText(text.replace(/[（）()]/g, ''))));
    identities.delete('');
    return identities;
}
function findDuplicateIndex(incoming, existing) {
    const incomingIds = wordIdentities(incoming);
    return existing.findIndex(word => [...wordIdentities(word)].some(identity => incomingIds.has(identity)));
}
function mergeList(target, incoming) { return unique([...asStringArray(target), ...asStringArray(incoming)]); }
function mergeWord(existing, incoming) {
    const merged = { ...existing };
    const conflicts = [];
    for (const field of ['category', 'eraTag', 'reading', 'kanji', 'english', 'column', 'memo', 'gemini_note']) {
        const oldValue = asString(existing[field]);
        const newValue = asString(incoming[field]);
        if (!newValue || newValue === oldValue) continue;
        if (!oldValue) merged[field] = newValue;
        else conflicts.push({ field, oldValue, newValue });
    }
    // Word name variants are useful: preserve the existing display title and add incoming spelling to other_tags.
    if (normalizeText(existing.word) !== normalizeText(incoming.word)) merged.other_tags = mergeList(merged.other_tags, [incoming.word]);
    merged.other_tags = mergeList(merged.other_tags, incoming.other_tags);
    const meanings = [...existing.meanings.map(clone)];
    for (const incomingMeaning of incoming.meanings) {
        const exact = meanings.find(meaning => normalizeText(meaning.definition) === normalizeText(incomingMeaning.definition));
        if (exact) {
            for (const field of ['background', 'nuance']) {
                if (!exact[field]) exact[field] = incomingMeaning[field];
                else if (incomingMeaning[field] && normalizeText(exact[field]) !== normalizeText(incomingMeaning[field])) conflicts.push({ field: `意味「${exact.definition}」の${field}`, oldValue: exact[field], newValue: incomingMeaning[field], meaning: exact });
            }
            exact.fieldTag = mergeList(exact.fieldTag, incomingMeaning.fieldTag);
            exact.examples = mergeList(exact.examples, incomingMeaning.examples);
            exact.synonyms = mergeList(exact.synonyms, incomingMeaning.synonyms);
        } else meanings.push(clone(incomingMeaning));
    }
    merged.meanings = meanings;
    if (conflicts.length) {
        const details = conflicts.map((item, i) => `${i + 1}. ${item.field}\n現在: ${item.oldValue}\n取込: ${item.newValue}`).join('\n\n');
        const useImported = confirm(`「${existing.word}」のマージで競合があります。\n\n${details}\n\nOK: 競合する値は取り込みデータを採用\nキャンセル: 現在の値を維持`);
        if (useImported) conflicts.forEach(item => {
            if (item.meaning) item.meaning[item.field.split('の').pop()] = item.newValue;
            else merged[item.field] = item.newValue;
        });
    }
    return merged;
}

async function readJsonFiles(files) {
    return Promise.all([...files].map(async file => {
        let parsed;
        try { parsed = JSON.parse(await file.text()); }
        catch (error) { throw new Error(`ファイル「${file.name}」のJSON解析に失敗しました: ${error.message}`); }
        try { return { name: file.name, ...parseNangoDocument(parsed) }; }
        catch (error) { throw new Error(`ファイル「${file.name}」: ${error.message}`); }
    }));
}
function triggerImport() { $('fileInput').click(); }
async function importJSON(event) {
    const files = event.target.files;
    if (!files || !files.length) return;
    try {
        const documents = await readJsonFiles(files);
        const incoming = documents.flatMap(doc => doc.words);
        const added = await applyImportedWords(incoming, documents.flatMap(doc => doc.additional_data));
        alert(`インポートが完了しました。\nファイル数: ${documents.length}\n追加: ${added.added}件\nマージ: ${added.merged}件\nスキップ: ${added.skipped}件`);
    } catch (error) { alert(`インポートを中止しました。現在のデータは変更していません。\n${error.message}`); }
    finally { event.target.value = ''; }
}
async function applyImportedWords(incoming, extra = []) {
    // Validate all inputs before mutating current state (transaction-like behavior).
    incoming.forEach(validateWord);
    const strategy = confirm('取り込み方法を選択してください。\n\nOK: 現在の辞書に追加・重複マージ\nキャンセル: 取り込み内容で辞書を置き換え');
    if (!strategy) {
        const replacement = incoming.map(clone);
        const deduped = [];
        let skipped = 0;
        for (const word of replacement) {
            const existingIndex = findDuplicateIndex(word, deduped);
            if (existingIndex < 0) deduped.push(word);
            else { deduped[existingIndex] = mergeWord(deduped[existingIndex], word); skipped++; }
        }
        wordData = reassignIds(deduped);
        additionalData = mergeList(extra, []);
        const first = wordData[0]; currentWordId = first ? first.id : -1;
        saveToLocalStorage(); refreshOpenState(); renderSidebarTree(); showViewMode();
        return { added: wordData.length, merged: 0, skipped };
    }
    const candidate = wordData.map(clone);
    let added = 0, mergedCount = 0, skipped = 0;
    for (const word of incoming) {
        const index = findDuplicateIndex(word, candidate);
        if (index < 0) { candidate.push({ ...clone(word), id: nextId(candidate) }); added++; }
        else { candidate[index] = mergeWord(candidate[index], word); mergedCount++; }
    }
    wordData = candidate;
    additionalData = mergeList(additionalData, extra);
    if (!wordData.some(item => item.id === currentWordId)) currentWordId = wordData[0]?.id ?? -1;
    saveToLocalStorage(); refreshOpenState(); renderSidebarTree(); showViewMode();
    return { added, merged: mergedCount, skipped };
}

function exportJSON() {
    if (!wordData.length) { alert('エクスポートする単語がありません。'); return; }
    let blob;
    try { blob = new Blob([JSON.stringify(serializeNangoDocument(), null, 2)], { type: 'application/json;charset=utf-8' }); }
    catch (error) { alert(`エクスポートできません: ${error.message}`); return; }
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'Nango-neo_DTformats.neo.v5.14.json';
    document.body.appendChild(anchor); anchor.click(); anchor.remove(); URL.revokeObjectURL(url);
}
function resetToDefault() {
    if (!confirm('辞書を初期データに戻しますか？\n追加・編集したデータは失われます。先にエクスポートしてください。')) return;
    wordData = reassignIds(clone(defaultData)); additionalData = []; currentWordId = wordData[0]?.id ?? -1;
    currentSort = 'id'; currentHierarchy = 'category'; searchQuery = ''; $('searchInput').value = '';
    $('sort-id').classList.add('active'); $('sort-alpha').classList.remove('active');
    $('struct-cat').classList.add('active'); $('struct-field').classList.remove('active'); $('struct-era').classList.remove('active');
    saveToLocalStorage(); refreshOpenState(); renderSidebarTree(); showViewMode();
}

function showManagePanel() {
    recordAppNavigation('manage');
    $('viewMode').style.display = 'none'; $('editMode').style.display = 'none'; $('pastePanelMode').style.display = 'none'; $('wordListMode').style.display = 'none'; $('managePanelMode').style.display = 'block';
    renderTagManagementTables();
}
function closeManagePanel() { showViewMode(); }
function renderTagManagementTables() {
    const fieldMap = new Map(), eraMap = new Map(), otherMap = new Map();
    for (const word of wordData) {
        for (const tag of unique(word.meanings.flatMap(m => m.fieldTag || []))) fieldMap.set(tag, (fieldMap.get(tag) || 0) + 1);
        if (word.eraTag) eraMap.set(word.eraTag, (eraMap.get(word.eraTag) || 0) + 1);
        for (const tag of word.other_tags || []) otherMap.set(tag, (otherMap.get(tag) || 0) + 1);
    }
    renderTagTable('fieldTagsTableContainer', fieldMap, 'fieldTag');
    renderTagTable('eraTagsTableContainer', eraMap, 'eraTag');
    renderTagTable('otherTagsTableContainer', otherMap, 'other_tags');
}
function renderTagTable(containerId, tagMap, type) {
    const container = $(containerId);
    if (!container) return;
    const sort = tagTableSortState[type] || { key: 'tag', direction: 'asc' };
    const direction = sort.direction === 'desc' ? -1 : 1;
    const entries = [...tagMap.entries()].sort(([tagA, countA], [tagB, countB]) => {
        const primary = sort.key === 'count' ? countA - countB : tagA.localeCompare(tagB, 'ja');
        return primary * direction || tagA.localeCompare(tagB, 'ja');
    });
    container.innerHTML = '';
    const table = document.createElement('table'); table.className = 'tag-table';
    table.innerHTML = `<thead><tr>
        <th><button type="button" class="table-sort-button" data-sort="tag">タグ名 ${sort.key === 'tag' ? (sort.direction === 'asc' ? '▲' : '▼') : '↕'}</button></th>
        <th><button type="button" class="table-sort-button" data-sort="count">該当単語数 ${sort.key === 'count' ? (sort.direction === 'asc' ? '▲' : '▼') : '↕'}</button></th>
        <th>操作</th></tr></thead>`;
    table.querySelectorAll('[data-sort]').forEach(button => {
        button.addEventListener('click', () => {
            const key = button.dataset.sort;
            const old = tagTableSortState[type] || { key: 'tag', direction: 'asc' };
            tagTableSortState[type] = { key, direction: old.key === key && old.direction === 'asc' ? 'desc' : 'asc' };
            renderTagTable(containerId, tagMap, type);
        });
    });
    const tbody = document.createElement('tbody');
    if (!entries.length) { tbody.innerHTML = '<tr><td colspan="3">登録されているタグはありません</td></tr>'; }
    else entries.forEach(([tag, count]) => {
        const row = document.createElement('tr');
        row.innerHTML = `<td><button type="button" class="tag-table-link">${escapeHtml(tag)}</button></td><td>${count} 件</td><td><button class="btn-sm" type="button">名称一括変更</button></td>`;
        row.querySelector('.tag-table-link').onclick = () => showWordsForTag(type, tag);
        row.querySelector('.btn-sm').onclick = () => renameTag(type, tag);
        tbody.appendChild(row);
    });
    table.appendChild(tbody); container.appendChild(table);
}

function renameTag(type, oldTag) {
    const label = type === 'fieldTag' ? '分野タグ' : type === 'eraTag' ? '時代タグ' : 'その他タグ';
    const newName = prompt(`現在の${label}: 「${oldTag}」\n新しい名前（空欄なら削除）`, oldTag);
    if (newName === null) return;
    const value = newName.trim();
    for (const word of wordData) {
        if (type === 'fieldTag') word.meanings.forEach(m => { m.fieldTag = unique(m.fieldTag.map(t => t === oldTag ? value : t)); });
        else if (type === 'eraTag' && word.eraTag === oldTag) word.eraTag = value;
        else if (type === 'other_tags') word.other_tags = unique(word.other_tags.map(t => t === oldTag ? value : t));
    }
    saveToLocalStorage(); refreshOpenState(); renderSidebarTree(); renderTagManagementTables();
}

function togglePastePanel() {
    const isVisible = $('pastePanelMode').style.display === 'block';
    if (isVisible) { showViewMode(); return; }
    recordAppNavigation('paste');
    $('viewMode').style.display = 'none'; $('editMode').style.display = 'none'; $('managePanelMode').style.display = 'none'; $('wordListMode').style.display = 'none'; $('pastePanelMode').style.display = 'block';
    $('jsonPasteInput').focus();
}
async function importPastedJSON() {
    try {
        const raw = $('jsonPasteInput').value.trim();
        if (!raw) throw new Error('JSONを貼り付けてください。');
        const parsed = parseNangoDocument(JSON.parse(raw));
        const result = await applyImportedWords(parsed.words, parsed.additional_data);
        $('jsonPasteInput').value = '';
        alert(`貼り付けデータを取り込みました。追加: ${result.added}件、マージ: ${result.merged}件`);
    } catch (error) { alert(`貼り付けデータを取り込めませんでした。\n${error.message}`); }
}
function showWordList() {
    wordListTagFilter = null;
    $('wordListSearch').value = '';
    $('wordListTagFilter').textContent = '';
    $('wordListTagFilter').style.display = 'none';
    recordAppNavigation('wordList');
    $('viewMode').style.display = 'none';
    $('editMode').style.display = 'none';
    $('managePanelMode').style.display = 'none';
    $('pastePanelMode').style.display = 'none';
    $('wordListMode').style.display = 'block';
    renderWordList();
}

function showWordsForTag(type, tag) {
    wordListTagFilter = { type, tag };
    $('wordListSearch').value = '';
    recordAppNavigation('tagWords');
    $('viewMode').style.display = 'none';
    $('editMode').style.display = 'none';
    $('managePanelMode').style.display = 'none';
    $('pastePanelMode').style.display = 'none';
    $('wordListMode').style.display = 'block';
    $('wordListTagFilter').style.display = 'flex';
    $('wordListTagFilter').innerHTML = `タグ「<strong>${escapeHtml(tag)}</strong>」が付いた単語 <button type="button" class="btn-sm" id="clearWordListTagFilter">タグ絞り込み解除</button>`;
    $('clearWordListTagFilter').onclick = () => { wordListTagFilter = null; $('wordListTagFilter').style.display = 'none'; renderWordList(); };
    renderWordList();
}

function wordHasTag(word, filter) {
    if (!filter) return true;
    if (filter.type === 'fieldTag') return word.meanings.some(meaning => (meaning.fieldTag || []).includes(filter.tag));
    if (filter.type === 'eraTag') return word.eraTag === filter.tag;
    if (filter.type === 'other_tags') return (word.other_tags || []).includes(filter.tag);
    return true;
}

function setWordListSort() { wordListColumnSort = { key: null, direction: 'asc' }; renderWordList(); }

function renderWordList() {
    const container = $('wordListContainer');
    if (!container) return;
    const query = normalizeText($('wordListSearch')?.value || '');
    const sort = $('wordListSort')?.value || 'id';
    const direction = $('wordListDirection')?.value || 'asc';
    const multiplier = direction === 'desc' ? -1 : 1;
    const columnSort = wordListColumnSort;
    let items = wordData.filter(word => (!query || normalizeText(searchableText(word)).includes(query)) && wordHasTag(word, wordListTagFilter));
    items = [...items].sort((a, b) => {
        let result;
        if (columnSort.key === 'reading') result = (a.reading || '').localeCompare(b.reading || '', 'ja') || a.word.localeCompare(b.word, 'ja');
        else if (columnSort.key === 'category') result = (a.category || '').localeCompare(b.category || '', 'ja') || a.word.localeCompare(b.word, 'ja');
        else if (columnSort.key === 'tags') {
            const tagsA = [...unique(a.meanings.flatMap(m => m.fieldTag || [])), a.eraTag, ...(a.other_tags || [])].filter(Boolean).sort((x,y)=>x.localeCompare(y,'ja')).join(' ');
            const tagsB = [...unique(b.meanings.flatMap(m => m.fieldTag || [])), b.eraTag, ...(b.other_tags || [])].filter(Boolean).sort((x,y)=>x.localeCompare(y,'ja')).join(' ');
            result = tagsA.localeCompare(tagsB, 'ja') || a.word.localeCompare(b.word, 'ja');
        } else if (columnSort.key === 'word') result = a.word.localeCompare(b.word, 'ja');
        else result = sort === 'alpha' ? (a.reading || a.word).localeCompare(b.reading || b.word, 'ja') || a.word.localeCompare(b.word, 'ja') : a.id - b.id;
        return result * (columnSort.key ? (columnSort.direction === 'desc' ? -1 : 1) : multiplier);
    });
    $('wordListCount').textContent = `${items.length}件 / 登録総数 ${wordData.length}件`;
    if (!items.length) {
        container.innerHTML = '<div class="empty-message">条件に一致する単語はありません。</div>';
        return;
    }
    const rows = items.map(word => {
        const tags = [
            ...unique(word.meanings.flatMap(m => m.fieldTag || [])).map(tag => `<button type="button" class="custom-tag tag-field tag-link" data-tag-type="fieldTag" data-tag-value="${escapeHtml(tag)}">${escapeHtml(tag)}</button>`),
            ...(word.eraTag ? [`<button type="button" class="custom-tag tag-era tag-link" data-tag-type="eraTag" data-tag-value="${escapeHtml(word.eraTag)}">${escapeHtml(word.eraTag)}</button>`] : []),
            ...(word.other_tags || []).map(tag => `<button type="button" class="custom-tag tag-other tag-link" data-tag-type="other_tags" data-tag-value="${escapeHtml(tag)}">${escapeHtml(tag)}</button>`)
        ].join('');
        return `<tr>
            <td><button class="word-list-open" type="button" data-word-id="${word.id}">${escapeHtml(word.word)}</button></td>
            <td>${escapeHtml(word.reading || '—')}</td>
            <td>${escapeHtml(word.category || '指定なし')}</td>
            <td><div class="word-list-tags">${tags || '—'}</div></td>
        </tr>`;
    }).join('');
    container.innerHTML = `<div class="word-list-table-wrap"><table class="word-list-table">
        <thead><tr>
          <th><button type="button" class="table-sort-button" data-column-sort="word">単語 ${columnSort.key === 'word' ? (columnSort.direction === 'asc' ? '▲' : '▼') : '↕'}</button></th>
          <th><button type="button" class="table-sort-button" data-column-sort="reading">読み ${columnSort.key === 'reading' ? (columnSort.direction === 'asc' ? '▲' : '▼') : '↕'}</button></th>
          <th><button type="button" class="table-sort-button" data-column-sort="category">分類 ${columnSort.key === 'category' ? (columnSort.direction === 'asc' ? '▲' : '▼') : '↕'}</button></th>
          <th><button type="button" class="table-sort-button" data-column-sort="tags">タグ ${columnSort.key === 'tags' ? (columnSort.direction === 'asc' ? '▲' : '▼') : '↕'}</button></th>
        </tr></thead><tbody>${rows}</tbody></table></div>`;
    container.querySelectorAll('[data-column-sort]').forEach(button => {
        button.addEventListener('click', () => {
            const key = button.dataset.columnSort;
            wordListColumnSort = { key, direction: wordListColumnSort.key === key && wordListColumnSort.direction === 'asc' ? 'desc' : 'asc' };
            renderWordList();
        });
    });
    container.querySelectorAll('[data-word-id]').forEach(button => {
        button.addEventListener('click', () => {
            currentWordId = Number(button.dataset.wordId);
            renderSidebarTree();
            showViewMode();
        });
    });
    container.querySelectorAll('[data-tag-type][data-tag-value]').forEach(tagButton => {
        tagButton.addEventListener('click', () => showWordsForTag(tagButton.dataset.tagType, tagButton.dataset.tagValue));
    });
}

function showTodaysWord() {
    if (!wordData.length) { alert('辞書に単語がありません。'); return; }
    const day = new Date();
    const dateSeed = Number(`${day.getFullYear()}${String(day.getMonth() + 1).padStart(2, '0')}${String(day.getDate()).padStart(2, '0')}`);
    const sorted = [...wordData].sort((a, b) => a.id - b.id);
    const selected = sorted[dateSeed % sorted.length];
    currentWordId = selected.id;
    renderSidebarTree(); showViewMode();
    $('todaysWordBanner').innerHTML = `<strong>今日の単語:</strong> ${escapeHtml(selected.word)} <span>（日付に基づいて毎日同じ単語を表示します）</span>`;
}

// Expose small pure helpers for browser console/manual tests.
window.NangoPhase1 = { parseNangoDocument, serializeNangoDocument, normalizeWord, validateWord, findDuplicateIndex, mergeWord, get data() { return clone(wordData); } };
initApp();
