/* Run from repository root: node test_or_future/phase1_smoke.test.js */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const sourcePath = path.join(__dirname, '..', 'Nango-neo', 'Nango_main.v01.0.0.js');
let source = fs.readFileSync(sourcePath, 'utf8');
source = source.replace(/\/\/ Expose small pure helpers for browser console\/manual tests\.[\s\S]*$/, '');
const api = new Function(`${source}\nreturn { parseNangoDocument, serializeNangoDocument, normalizeWord, validateWord, findDuplicateIndex, mergeWord, reassignIds };`)();

const canonical = {
  words: {
    'カスケード（cascade）': {
      id: 90,
      datetime: '2026-10-09T10:00:00+09:00',
      category: '外来語', eraTag: '現代', reading: 'かすけーど', kanji: '', english: 'cascade',
      column: '', memo: '', gemini_note: '', other_tags: ['IT'],
      meanings: [
        { definition: '意味A', background: '', nuance: '', fieldTag: ['IT'], examples: ['例1'], synonyms: ['連鎖'] },
        { definition: '意味B', background: '背景B', nuance: '', fieldTag: ['科学'], examples: [], synonyms: [] }
      ]
    }
  },
  additional_data: []
};

const parsed = api.parseNangoDocument(canonical);
assert.equal(parsed.words.length, 1, 'canonical words object is parsed');
assert.equal(parsed.words[0].meanings.length, 2, 'multiple meanings are retained');
assert.equal(parsed.words[0].id, 90, 'existing ID is read before reassignment');

const exported = api.serializeNangoDocument(api.reassignIds(parsed.words));
assert.ok(exported.words['カスケード（cascade）'], 'export is keyed by display word');
assert.equal(exported.words['カスケード（cascade）'].id, 1, 'export IDs follow registration order after reassignment');
assert.equal('word' in exported.words['カスケード（cascade）'], false, 'word name is not redundantly stored inside the entry');
assert.equal(exported.words['カスケード（cascade）'].meanings.length, 2, 'export retains each meaning');

const oldArray = api.parseNangoDocument([
  { id: 44, word: '旧形式', category: 'その他', meaning: '旧定義', background: '旧背景', nuance: '', fieldTag: '旧タグ', examples: ['旧例'], synonyms: ['旧語'] }
]);
assert.equal(oldArray.words[0].meanings[0].definition, '旧定義', 'old array format is migrated');
assert.deepEqual(oldArray.words[0].meanings[0].fieldTag, ['旧タグ'], 'old single fieldTag is migrated to a list');

const markedRequired = api.parseNangoDocument({ words: { 'マーカー': { meanings: [{ 'definition$': '必須キー末尾マーカーを移行' }] } } });
assert.equal(markedRequired.words[0].meanings[0].definition, '必須キー末尾マーカーを移行', 'legacy $ field markers are normalized');
assert.throws(() => api.parseNangoDocument({ words: { '未定義': { meanings: [{ background: '定義なし' }] } } }), /definition/, 'missing required definition is rejected');
assert.throws(() => api.parseNangoDocument({ words: { '日時不正': { datetime: 'yyyymmdd_HHMM', meanings: [{ definition: '定義' }] } } }), /RFC 3339/, 'invalid canonical date is rejected');

const duplicateCandidate = api.normalizeWord({ word: 'カスケード', meanings: [{ definition: '別定義' }] }, 'カスケード');
assert.equal(api.findDuplicateIndex(duplicateCandidate, parsed.words), 0, 'parenthesized spelling variants are treated as duplicates');
const merged = api.mergeWord(parsed.words[0], api.normalizeWord({ word: 'カスケード', category: '外来語', meanings: [{ definition: '意味A', fieldTag: ['工学'], examples: ['例2'], synonyms: ['波及'] }] }, 'カスケード'));
assert.ok(merged.meanings[0].fieldTag.includes('工学'), 'list tags merge without removing existing values');
assert.ok(merged.meanings[0].examples.includes('例2'), 'examples merge without removing existing values');
assert.ok(merged.meanings[0].synonyms.includes('波及'), 'synonyms merge without removing existing values');

console.log('Phase 1 JavaScript smoke tests: 11 assertions passed.');
