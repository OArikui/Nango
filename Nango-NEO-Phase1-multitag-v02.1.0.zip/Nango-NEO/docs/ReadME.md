# Nango-neo

## 現行版

- 画面: `Nango-neo/Nango-neo.v02.1.0.html`
- JavaScript: `Nango-neo/Nango_main.v01.1.0.js`
- CSS: `Nango-neo/style.v02.1.0.css`
- データ形式: `Nango-neo/DTformats.neo.v5.12/`
- Phase 1実装記録: `docs/PHASE1_IMPLEMENTATION.md`

## 起動方法

1. `Nango-neo/Nango-neo.v02.1.0.html` をブラウザーで開きます。
2. ブラウザーの `localStorage` に辞書を保存します。データは同じブラウザー・同じオリジンで利用します。
3. バックアップや別環境への移行には、画面上の「JSONエクスポート」を利用してください。

ローカルファイルとして開いたときにブラウザーが保存を制限する場合は、PowerShellなどで `Nango-neo` フォルダーへ移動し、`py -m http.server 8000` を実行して `http://localhost:8000/Nango-neo.v02.0.0.html` を開いてください。サーバーを使う場合、`file://` で保存したデータとは保存領域が異なります。

## 単語一覧機能

画面上部の「📚 単語一覧」から登録済み単語を一覧表示できます。単語名・読み・分類・タグを確認でき、登録順／五十音順の切り替えと一覧内検索が可能です。単語名を選択すると、その単語の詳細画面へ移動します。

## データ形式

JSON Schema Draft 2020-12を基準にし、単語名を `words` オブジェクトのキーとして保持します。1語の中に `meanings` 配列を置き、意味ごとに定義・背景・ニュアンス・分野タグ・例文・類義語を保存します。登録日時の `datetime` は RFC 3339形式です。

```json
{
  "words": {
    "単語名": {
      "id": 1,
      "datetime": "2026-10-09T10:00:00+09:00",
      "category": "カテゴリ",
      "meanings": [
        {
          "definition": "必須の意味・定義",
          "fieldTag": ["分野タグ"],
          "examples": [],
          "synonyms": []
        }
      ]
    }
  },
  "additional_data": []
}
```

`words` はオブジェクトであり、キーが表示名です。単語名を別の `word` / `word(any)` 項目として重複保存しません。各単語には1つ以上の `meanings`、各意味には空でない `definition` が必要です。IDは追加・インポート時に登録順に合わせて採番し直します。

## インポート時の扱い

- DTformats.neo.v5.12形式を読み込みます。旧版の単語配列JSONも移行用として受け付けます。
- 複数のJSONファイルを一度に選択できます。いずれかのファイルが不正なら、現データを変更せずに取り込みを中止します。
- 既存辞書へ追加する場合、単語名・括弧内表記の重複を判定してマージします。リスト型タグ・例文・類義語は自動統合し、テキスト項目が競合するときは選択を求めます。
- JSON貼り付け欄からも同じ取り込み処理を利用できます。
- エクスポートはDTformats.neo.v5.12形式です。

## テスト

開発用に `jsonschema`（Draft 2020-12対応）とNode.jsを用います。

```powershell
node test_or_future/phase1_smoke.test.js
python -m unittest test_or_future.test_phase1_format -v
```

ブラウザーのデータは定期的にエクスポートしてください。Phase 1ではアカウント同期・サーバー保存は提供していません。
